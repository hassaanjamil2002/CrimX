import hashlib

def calculate_md5_hash(file_path):
    """Calculate the MD5 hash of a file."""
    hash_md5 = hashlib.md5()
    with open(file_path, "rb") as f:
        # Read and update hash string value in blocks of 4K
        for chunk in iter(lambda: f.read(4096), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()
    
def verify_file_hash(file_path, expected_hash):
    """Verify if the calculated hash of the file matches the expected hash."""
    actual_hash = calculate_md5_hash(file_path)
    if actual_hash == expected_hash:
        print("The file is intact and has not been tampered with.")
        return True
    else:
        print("File integrity check failed. The file may have been tampered with.")
        return False

# Usage
file_path = 'Project_db.sql'
precalculated_hash = '9c6a0995885b40bd3377ce001d61f806'

# Verify the file integrity
verify_file_hash(file_path, precalculated_hash)
