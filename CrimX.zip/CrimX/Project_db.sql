create database project;
use project;
ALTER DATABASE project SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
ALTER DATABASE project SET MULTI_USER;

drop DATABASE project;
-- Crime Table

drop table Crime;
drop table Officer;
drop table Punishment;
drop table Victim;
drop table Accused;
drop table Judge;
drop table Court;
DELETE FROM Crime1;
DELETE FROM Victim1;
DELETE FROM Accused1;
DELETE FROM Punishment;
DELETE FROM Evidence1;
DELETE FROM Court;
DELETE FROM Officer;
DELETE FROM Users

CREATE TABLE Crime1 (
    Crime_ID INT PRIMARY KEY, --FIR_ID is Crime_iD
    FIR_date DATE,
    crime_name VARCHAR(255),
    crime_code VARCHAR(20),
    crime_type VARCHAR(50),	
    crime_location VARCHAR(255),
    punishment_ID INT FOREIGN KEY REFERENCES Punishment(	punishment_ID)
);

-- Accused Table
CREATE TABLE Accused1 (
    accused_ID INT PRIMARY KEY,
    accused_name VARCHAR(255),
    accused_gender VARCHAR(10),
    accused_age INT,
    accused_cnic VARCHAR(15),
    accused_guardian_name VARCHAR(255),
    accused_address VARCHAR(255),
    accused_judgement VARCHAR(255),	
    accused_DOB DATE,
    accused_phone VARCHAR(20),
    crime_ID INT FOREIGN KEY REFERENCES Crime1(Crime_id),
    punishment_ID INT FOREIGN KEY REFERENCES Punishment(punishment_ID),
    court_ID INT FOREIGN KEY REFERENCES Court(Court_ID),
    officer_ID INT FOREIGN KEY REFERENCES Officer(officer_ID)
);

-- Punishment Table
CREATE TABLE Punishment (
    punishment_ID INT PRIMARY KEY,
    punishment_name VARCHAR(255),
    punishment_code VARCHAR(20),
    punishment_length FLOAT,
    punishment_damages INT NULL,
    court_ID INT FOREIGN KEY REFERENCES Court(Court_ID)
	
);

-- Court Table

CREATE TABLE Users (
	Email VARCHAR(255),
	Pass VARCHAR(255));
CREATE TABLE Court (
    Court_ID INT PRIMARY KEY,
    Court_name VARCHAR(255),
    Court_position VARCHAR(50),
    judge_ID INT FOREIGN KEY REFERENCES Judge(judge_ID)
);

-- Victim Table
CREATE TABLE Victim1 (
    victim_ID INT PRIMARY KEY,
    victim_name VARCHAR(255),
    victim_injuries VARCHAR(255),
    victim_testimony TEXT,
    victim_gender VARCHAR(10),
    victim_age INT,
    victim_cnic VARCHAR(15),
    victim_guardian_name VARCHAR(255),
    victim_DOB DATE,
    victim_phone VARCHAR(20),
    crime_ID INT FOREIGN KEY REFERENCES Crime1(Crime_id)
);

-- Evidence Table
CREATE TABLE Evidence1 (
    evidence_ID INT PRIMARY KEY,
    evidence_type VARCHAR(50),
    evidence_source VARCHAR(255),
    evidence_date_of_collection DATE,
    evidence_status VARCHAR(50),
    evidence_description TEXT,
    crime_ID INT FOREIGN KEY REFERENCES Crime1(Crime_id),
    officer_ID INT FOREIGN KEY REFERENCES Officer(officer_ID)
);

-- Officer Table
CREATE TABLE Officer (
    officer_ID INT PRIMARY KEY,
    officer_name VARCHAR(255),
    officer_gender VARCHAR(10),
    officer_age INT,
    officer_cnic VARCHAR(15),
    officer_DOB DATE,
    officer_phone VARCHAR(20)
);

-- Judge Table
CREATE TABLE Judge (
    judge_ID INT PRIMARY KEY,
    judge_name VARCHAR(255),
    judge_age INT,
    judge_cnic VARCHAR(15),
    judge_DOB DATE,
    judge_phone VARCHAR(20)
);

INSERT INTO Users (Email, Pass,Role)
VALUES

('hassaan52@gmail.com','123','Admin'),
('wahab@gmail.com','234','User');
ALTER TABLE Users ADD Role VARCHAR(50);

INSERT INTO Judge (judge_ID, judge_name, judge_age, judge_cnic, judge_DOB, judge_phone)
VALUES
    (1, 'John Doe', 45, '123456789012345', '1978-05-15', '555-1234'),
    (2, 'Jane Smith', 38, '987654321098765', '1985-10-22', '555-5678'),
    (3, 'Robert Johnson', 50, '112233445566778', '1973-08-30', '555-9876'),
    (4, 'Emily Davis', 41, '223344556677889', '1982-06-12', '555-8765'),
    (5, 'Michael White', 55, '334455667788990', '1968-02-05', '555-2345'),
    (6, 'Olivia Robinson', 36, '445566778899001', '1987-11-18', '555-5432'),
    (7, 'William Brown', 48, '556677889900112', '1975-09-25', '555-6789'),
    (8, 'Sophia Garcia', 39, '667788990011223', '1984-04-20', '555-7890'),
    (9, 'James Martinez', 52, '778899001122334', '1971-12-08', '555-3456'),
    (10, 'Ava Jackson', 42, '889900112233445', '1981-07-03', '555-4567');

	INSERT INTO Officer (officer_ID, officer_name, officer_gender, officer_age, officer_cnic, officer_DOB, officer_phone)
VALUES
    (1, 'Officer Johnson', 'Male', 35, '112233445566778', '1988-12-10', '555-1111'),
    (2, 'Officer Williams', 'Female', 40, '223344556677889', '1982-08-25', '555-2222'),
    (3, 'Officer Davis', 'Male', 30, '334455667788990', '1991-05-03', '555-3333'),
    (4, 'Officer Smith', 'Female', 45, '445566778899001', '1980-02-15', '555-4444'),
    (5, 'Officer White', 'Male', 38, '556677889900112', '1985-09-20', '555-5555'),
    (6, 'Officer Robinson', 'Female', 42, '667788990011223', '1983-04-12', '555-6666'),
    (7, 'Officer Brown', 'Male', 34, '778899001122334', '1990-11-08', '555-7777'),
    (8, 'Officer Garcia', 'Female', 47, '889900112233445', '1976-07-23', '555-8888'),
    (9, 'Officer Martinez', 'Male', 39, '990011223344556', '1982-01-30', '555-9999'),
    (10, 'Officer Jackson', 'Female', 44, '001122334455667', '1977-08-05', '555-0000');

	INSERT INTO Punishment (punishment_ID, punishment_name, punishment_code, punishment_length, punishment_damages, court_ID)
VALUES
    (1, 'Prison Sentence', 'PS001', 5.5, NULL, 1),
    (2, 'Fine', 'F002', 0, 10000, 2),
    (3, 'Community Service', 'CS003', 120, NULL, 3),
    (4, 'Probation', 'PB004', 2, NULL, 4),
    (5, 'Restitution', 'RT005', 0, 5000, 5),
    (6, 'House Arrest', 'HA006', 3, NULL, 1),
    (7, 'Suspension of License', 'SL007', 0, NULL, 2),
    (8, 'Counseling', 'CC008', 10, NULL, 3),
    (9, 'Public Apology', 'PA009', 0, NULL, 4),
    (10, 'Electronic Monitoring', 'EM010', 6, NULL, 5);

	INSERT INTO Court (Court_ID, Court_name, Court_position, judge_ID)
VALUES
    (1, 'District Court', 'Judge', 1),
    (2, 'City Court', 'Magistrate', 2),
    (3, 'County Court', 'Judge', 3),
    (4, 'Family Court', 'Magistrate', 4),
    (5, 'Supreme Court', 'Judge', 5),
    (6, 'High Court', 'Judge', 6),
    (7, 'Municipal Court', 'Magistrate', 7),
    (8, 'Federal Court', 'Judge', 8),
    (9, 'Appellate Court', 'Judge', 9),
    (10, 'Circuit Court', 'Magistrate', 10);

	INSERT INTO Evidence1 (evidence_ID, evidence_type, evidence_source, evidence_date_of_collection, evidence_status, evidence_description, crime_ID, officer_ID)
VALUES
    (1, 'Weapon', 'Crime Scene', '2023-01-20', 'Available', 'Found at the crime scene.', 1, 1),
    (2, 'Document', 'Witness Statement', '2023-02-05', 'Pending Analysis', 'Document from a witness.', 2, 2),
    (3, 'Forensic Sample', 'Lab', '2023-03-12', 'Analyzed', 'DNA sample from the crime scene.', 3, 3),
    (4, 'Surveillance Footage', 'Security Cameras', '2023-04-01', 'Under Review', 'Footage capturing the crime.', 4, 4),
    (5, 'Photograph', 'Photographer', '2023-05-18', 'Available', 'Photo of the crime scene.', 5, 5),
    (6, 'Audio Recording', 'Audio Devices', '2023-06-30', 'Under Review', 'Recording of a conversation related to the crime.', 6, 6),
    (7, 'Digital Evidence', 'Computers', '2023-07-15', 'Pending Analysis', 'Digital evidence from a suspect�s device.', 7, 7),
    (8, 'Biological Sample', 'Lab', '2023-08-22', 'Analyzed', 'Biological sample linking the suspect to the crime.', 8, 8),
    (9, 'Video Recording', 'Security Cameras', '2023-09-10', 'Under Review', 'Video capturing the crime in progress.', 9, 9),
    (10, 'Witness Testimony', 'Witness', '2023-10-05', 'Verified', 'Testimony supporting the case.', 10, 10);

	INSERT INTO Victim1 (victim_ID, victim_name, victim_injuries, victim_testimony, victim_gender, victim_age, victim_cnic, victim_guardian_name, victim_DOB, victim_phone, crime_ID)
VALUES
    (1, 'Alice Johnson', 'Minor injuries', 'I saw the suspect fleeing the scene.', 'Female', 25, '123451234512345', 'John Johnson', '1998-03-12', '555-3333', 1),
    (2, 'Bob Smith', 'None', 'I didn�t see anything, just heard gunshots.', 'Male', 30, '543215432154321', 'Mary Smith', '1993-08-18', '555-4444', 2),
    (3, 'Eva Davis', 'Bruises', 'The suspect attacked me during the robbery.', 'Female', 28, '654321654321987', 'David Davis', '1995-11-05', '555-5555', 3),
    (4, 'Daniel White', 'Serious injuries', 'I was assaulted by the suspect.', 'Male', 35, '765432765432109', 'Laura White', '1988-04-20', '555-6666', 4),
    (5, 'Grace Robinson', 'None', 'I witnessed the crime from my window.', 'Female', 40, '876543876543210', 'Peter Robinson', '1983-09-15', '555-7777', 5),
    (6, 'Henry Brown', 'Minor injuries', 'The suspect tried to steal my wallet.', 'Male', 22, '987654987654321', 'Olivia Brown', '2001-02-28', '555-8888', 6),
    (7, 'Isabella Garcia', 'Emotional trauma', 'The suspect threatened me during the incident.', 'Female', 27, '109876109876543', 'Carlos Garcia', '1996-07-10', '555-9999', 7),
    (8, 'Jack Martinez', 'None', 'I didn�t witness the crime but heard about it.', 'Male', 32, '210987210987654', 'Sophie Martinez', '1989-12-25', '555-0000', 8),
    (9, 'Kayla Jackson', 'Minor injuries', 'The suspect grabbed my purse and pushed me.', 'Female', 29, '321098321098765', 'Robert Jackson', '1994-05-18', '555-1111', 9),
    (10, 'Liam Taylor', 'Serious injuries', 'I was attacked by the suspect with a weapon.', 'Male', 33, '432109432109876', 'Emma Taylor', '1988-10-03', '555-2222', 10);

INSERT INTO Crime1 (Crime_ID, FIR_date, crime_name, crime_code, crime_type, crime_location, punishment_ID)
VALUES
    (1, '2023-01-15', 'Robbery', 'RB001', 'Violent', 'Street A', 1),
    (2, '2023-02-01', 'Fraud', 'FD002', 'White Collar', 'Office Building B', 2),
    (3, '2023-03-10', 'Assault', 'AS003', 'Violent', 'Park C', 3),
    (4, '2023-04-05', 'Burglary', 'BG004', 'Property Crime', 'Residence D', 4),
    (5, '2023-05-20', 'Homicide', 'HM005', 'Violent', 'Alley E', 5),
    (6, '2023-06-15', 'Theft', 'TH006', 'Property Crime', 'Store F', 6),
    (7, '2023-07-01', 'Stalking', 'SK007', 'Harassment', 'Home G', 7),
    (8, '2023-08-08', 'Forgery', 'FG008', 'White Collar', 'Bank H', 8),
    (9, '2023-09-25', 'Kidnapping', 'KD009', 'Violent', 'Street I', 9),
    (10, '2023-10-10', 'Arson', 'AR010', 'Property Crime', 'Warehouse J', 10);

	SELECT * from Officer;
	SELECT * from Judge;
	SELECT * from Court;
	SELECT * from Crime1;
	SELECT * from Accused1; 
	SELECT * From Victim1;
	SELECT * From Punishment;
	SELECT * From Users;
	
	SELECT	
    Accused.accused_ID,
    Accused.accused_name,
    Crime.crime_name,
    Crime.crime_type,
    Crime.crime_location,
    Officer.officer_name,
    Crime.FIR_date,
    Court.Court_position AS court_location
FROM
    Accused
    INNER JOIN Crime ON Accused.crime_ID = Crime.FIR_id
    INNER JOIN Officer ON Accused.officer_ID = Officer.officer_ID
    INNER JOIN Court ON Accused.court_ID = Court.Court_ID;

		SELECT 
		A.accused_ID,
		A.accused_name,
		CR.crime_ID,
		CR.punishment_ID,
		P.court_ID,
		C.court_name,
		C.judge_ID,
		J.judge_name
	FROM 
		Accused1 A
	JOIN 
		Crime1 CR ON A.crime_ID = CR.Crime_ID
	JOIN 
		Punishment P ON CR.punishment_ID = P.punishment_ID
	JOIN 
		Court C ON P.court_ID = C.court_ID
	JOIN 
		Judge J ON C.judge_ID = J.judge_ID;
