using System;

using System.Windows.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;

using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

using MySql.Data.MySqlClient;

namespace PROJECT_WINDOWS_APP
{
    public partial class FIR : Form
    {
        private string connectionString = "Data Source=DESKTOP-5A4OINC\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
        public FIR()
        {
            InitializeComponent();
            LoadNextAccusedID();
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }
        private void LoadNextAccusedID()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string sqlCommand = "SELECT ISNULL(MAX(accused_ID), 0) + 1 FROM Accused1";
                    using (SqlCommand command = new SqlCommand(sqlCommand, connection))
                    {
                        int nextAccusedID = Convert.ToInt32(command.ExecuteScalar());
                        AccusedID.Text = nextAccusedID.ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }
        public static string XorEncrypt(string text, string key)
        {
            char[] result = new char[text.Length];
            for (int i = 0; i < text.Length; i++)
            {
                result[i] = (char)(text[i] ^ key[i % key.Length]);
            }
            return new string(result);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //button
            string encryptionKey = "!z6#K2f&9LpR4@n1\r\n";

            // Get values from textboxes
            string AccusedIDD = AccusedID.Text;
            string AccusedNamee = AccusedName.Text;
            string AccusedCNIC = Accused_CNIC.Text;
            string AccusedGuardian = AccusedGuard.Text;
            string AccusedAddress = AccusedAdd.Text;
            //string textbox7Value = CrimeStatus.Text;
            string AccusedPhonee = AccusedPhone.Text;
            string AccusedGen = Accused_Gender.Text;
            DateTime DOB = Accused_DOB.Value;
            string Court = Court_ID.Text;
            string Crime = Crime_ID.Text;
            string Officer = Officer_ID.Text;
            int age = CalculateAge(DOB);
            string encryptedName = XorEncrypt(AccusedNamee, encryptionKey);
            string encryptedCNIC = XorEncrypt(AccusedCNIC, encryptionKey);
            string encryptedPhone = XorEncrypt(AccusedPhonee, encryptionKey);

            // Connection string - replace with your database connection string
            string connectionString = "Data Source=DESKTOP-5A4OINC\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";

            // Insert into Accused table
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string accusedInsertQuery = "INSERT INTO Accused1 (accused_ID, accused_name, accused_address,accused_phone,accused_DOB,accused_gender,accused_age,accused_CNIC,court_ID,crime_ID,officer_ID,accused_guardian_name)" +
                    " VALUES (@id, @name, @add,@phone,@dob,@gender,@age,@cnic,@court,@crime,@officer,@guardian)";
                using (SqlCommand command = new SqlCommand(accusedInsertQuery, connection))
                {
                    command.Parameters.AddWithValue("@id", AccusedIDD);
                    command.Parameters.AddWithValue("@name", encryptedName);
                    command.Parameters.AddWithValue("@add", AccusedAddress);
                    command.Parameters.AddWithValue("@phone", encryptedPhone);
                    command.Parameters.AddWithValue("@dob", DOB);
                    command.Parameters.AddWithValue("@gender", AccusedGen);
                    command.Parameters.AddWithValue("@cnic", encryptedCNIC);
                    command.Parameters.AddWithValue("@court", Court);
                    command.Parameters.AddWithValue("@crime", Crime);
                    command.Parameters.AddWithValue("@officer", Officer);
                    command.Parameters.AddWithValue("@age", age);
                    command.Parameters.AddWithValue("@guardian", AccusedGuardian);

                    command.ExecuteNonQuery();
                }
            }

            LoadNextAccusedID();

        }



        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {
        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click_2(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click_1(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void Crime_ID_TextChanged(object sender, EventArgs e)
        {

        }

        private void Court_ID_TextChanged(object sender, EventArgs e)
        {

        }

        private void Officer_ID_TextChanged(object sender, EventArgs e)
        {

        }

        private void Accused_DOB_ValueChanged(object sender, EventArgs e)
        {

        }
        private int CalculateAge(DateTime DOB)
        {
            DateTime currentDate = DateTime.Now;
            int age = currentDate.Year - DOB.Year;

            // Adjust age if the birthday hasn't occurred yet this year
            if (currentDate.Month < DOB.Month || (currentDate.Month == DOB.Month && currentDate.Day < DOB.Day))
            {
                age--;
            }

            return age;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}