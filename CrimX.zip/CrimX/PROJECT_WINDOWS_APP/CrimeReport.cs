﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PROJECT_WINDOWS_APP
{
    public partial class CrimeReport : Form
    {
        private const string ConnectionString = "Data Source=DESKTOP-5A4OINC\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True"; // Replace with your actual connection string

        public CrimeReport()
        {
            InitializeComponent();
            BindDataToGrid();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

        }
        public static string XorEncryptDecrypt(string text, string key)
        {
            char[] result = new char[text.Length];
            for (int i = 0; i < text.Length; i++)
            {
                result[i] = (char)(text[i] ^ key[i % key.Length]);
            }
            return new string(result);
        }

        private void BindDataToGrid()
        {
            DataTable dataTable = GetDataFromDatabase();
            dataGridView1.DataSource = dataTable;
        }
        private void saveToCsvButton_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "CSV files (*.csv)|*.csv|All files (*.*)|*.*";
            saveFileDialog.Title = "Save CSV File";

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                SaveDataGridViewToCsv(dataGridView1, saveFileDialog.FileName);
            }
        }
        private void SaveDataGridViewToCsv(DataGridView dataGridView, string filePath)
        {
            try
            {
                // Create a StreamWriter and write the column headers
                using (StreamWriter sw = new StreamWriter(filePath, false))
                {
                    for (int i = 0; i < dataGridView.ColumnCount; i++)
                    {
                        sw.Write(dataGridView.Columns[i].HeaderText);
                        if (i < dataGridView.ColumnCount - 1)
                            sw.Write(",");
                        else
                            sw.WriteLine();
                    }

                    // Write the data
                    for (int i = 0; i < dataGridView.RowCount; i++)
                    {
                        for (int j = 0; j < dataGridView.ColumnCount; j++)
                        {
                            sw.Write(dataGridView.Rows[i].Cells[j].Value);
                            if (j < dataGridView.ColumnCount - 1)
                                sw.Write(",");
                            else
                                sw.WriteLine();
                        }
                    }
                }

                MessageBox.Show("Data saved to CSV successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public DataTable GetDataFromDatabase()
        {
            DataTable dataTable = new DataTable();
            string encryptionKey = "!z6#K2f&9LpR4@n1\r\n";
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();

                // Replace this query with your actual SQL query
                string sqlQuery = "\tSELECT \r\n\t\tA.accused_ID,\r\n\t\tA.accused_name,\r\n\t\tCR.crime_ID,\r\n\t\tCR.punishment_ID,\r\n\t\tP.court_ID,\r\n\t\tC.court_name,\r\n\t\tC.judge_ID,\r\n\t\tJ.judge_name\r\n\tFROM \r\n\t\tAccused1 A\r\n\tJOIN \r\n\t\tCrime1 CR ON A.crime_ID = CR.Crime_ID\r\n\tJOIN \r\n\t\tPunishment P ON CR.punishment_ID = P.punishment_ID\r\n\tJOIN \r\n\t\tCourt C ON P.court_ID = C.court_ID\r\n\tJOIN \r\n\t\tJudge J ON C.judge_ID = J.judge_ID;\r\n";

                using (SqlCommand command = new SqlCommand(sqlQuery, connection))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        adapter.Fill(dataTable);
                    }
                }
            }
            foreach (DataRow row in dataTable.Rows)
            {
                row["accused_name"] = XorEncryptDecrypt(row["accused_name"].ToString(), encryptionKey);
              //  row["accused_CNIC"] = XorEncryptDecrypt(row["accused_CNIC"].ToString(), encryptionKey);
            //    row["accused_phone"] = XorEncryptDecrypt(row["accused_phone"].ToString(), encryptionKey);
            }
            return dataTable;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            saveToCsvButton_Click(sender, e);
        }

        private void CrimeReport_Load(object sender, EventArgs e)
        {

        }
    }
}
