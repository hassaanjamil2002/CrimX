﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PROJECT_WINDOWS_APP
{
    public partial class VictimCrime : Form
    {
        private const string ConnectionString = "Data Source=DESKTOP-5A4OINC\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True"; // Replace with your actual connection string

        public VictimCrime()
        {
            InitializeComponent();
            BindDataToGrid();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

        }
        private void BindDataToGrid()
        {
            DataTable dataTable = GetDataFromDatabase();
            dataGridView1.DataSource = dataTable;
        }

        public DataTable GetDataFromDatabase()
        {
            DataTable dataTable = new DataTable();

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();

                // Replace this query with your actual SQL query
                string sqlQuery = "SELECT\r\n    Victim1.victim_ID,\r\n    Victim1.victim_name,\r\n    Victim1.victim_injuries,\r\n    Victim1.victim_testimony,\r\n    Victim1.victim_gender,\r\n    Victim1.victim_age,\r\n    Victim1.victim_cnic,\r\n    Victim1.victim_guardian_name,\r\n    Victim1.victim_DOB,\r\n    Victim1.victim_phone,\r\n    Crime1.Crime_ID AS crime_ID\r\nFROM\r\n    Victim1\r\nJOIN\r\n    Crime1 ON Victim1.crime_ID = Crime1.Crime_ID;\r\n";

                using (SqlCommand command = new SqlCommand(sqlQuery, connection))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        adapter.Fill(dataTable);
                    }
                }
            }

            return dataTable;
        }
    }
}
