﻿using Microsoft.VisualStudio.OLE.Interop;
using System.Collections.Specialized;
using System.Data.SqlClient;
using System.Security.Cryptography;

namespace PROJECT_WINDOWS_APP
{
    public partial class Authentication : Form
    {
        public static string checkHash(string filename)
        {
            using (var md5 = MD5.Create())
            {
                using (var stream = File.OpenRead(filename))
                {
                    var hash = md5.ComputeHash(stream);
                    return BitConverter.ToString(hash).Replace("-", "").ToLowerInvariant();
                }
            }

        }
      /*  public static bool VerifyIntegrity(string filename, string expectedHash)
        {
            string fileHash = checkHash(filename);
            return fileHash.Equals(expectedHash);
        }*/
        public Authentication()
        {
            
            InitializeComponent();

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
        private void button1_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-5A4OINC\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            string email = textBox1.Text;
            string password = textBox2.Text;
            string role;
            string sqlFilePath = @"Project_db.sql";
            string expectedHash = "3ae01f26b37e90d7a8364d080f6ae09b";
            
                if (ValidateUser(email, password, connectionString, out role))
                {
                    MessageBox.Show("Login successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Hide();

                    // Check the role after successful login
                    if (role == "Admin")
                    {
                        MainMenu mainMenu = new MainMenu();
                        mainMenu.FormClosed += (s, args) => this.Close();
                        mainMenu.Show();
                    }
                    else if (role == "User")
                    {
                        FIR firForm = new FIR();
                        firForm.FormClosed += (s, args) => this.Close();
                        firForm.Show();
                    }
                }
                else
                {
                    MessageBox.Show("Login failed. Check username and password.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            
            
        }

        private bool ValidateUser(string email, string password, string connectionString, out string role)
        {
            role = null;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                // Updated SQL query to retrieve the password and role for the user
                string query = "SELECT Pass, Role FROM Users WHERE Email = @Email";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Email", email);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read()) // Check if the user exists
                        {
                            string storedPassword = reader["Pass"] as string;
                            role = reader["Role"] as string;

                            if (password == storedPassword) // Check if the password matches
                            {
                                return true; // User is validated
                            }
                        }
                        return false; // No user found or password does not match
                    }
                }
            }
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
