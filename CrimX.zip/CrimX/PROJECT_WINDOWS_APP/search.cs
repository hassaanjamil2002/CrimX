﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PROJECT_WINDOWS_APP
{
    public partial class search : Form
    {
        private const string ConnectionString = "Data Source=DESKTOP-5A4OINC\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True"; // Replace with your actual connection string

        public search()
        {
            InitializeComponent();
         //   BindDataToGrid();
           // button1.Click += button1_Click;
        }
      /*  private void BindDataToGrid()
        {


            string accusedName = textBox1.Text.Trim(); // Assuming you have a TextBox named textBoxAccusedName
            DataTable dataTable = GetDataFromDatabase(accusedName);
            dataGridView1.DataSource = dataTable;
        }
*/
        public DataTable GetDataFromDatabase(string accusedName)
        {
            DataTable dataTable = new DataTable();

            using (SqlConnection connection = new SqlConnection(ConnectionString ))
            {
                connection.Open();

                // Replace this query with your actual SQL query
                string sqlQuery = "\tSELECT \r\n\t\tA.accused_ID,\r\n\t\tA.accused_name,\r\n\t\tCR.crime_ID,\r\n\t\tCR.punishment_ID,\r\n\t\tP.court_ID,\r\n\t\tC.court_name,\r\n\t\tC.judge_ID,\r\n\t\tJ.judge_name\r\n\tFROM \r\n\t\tAccused1 A\r\n\tJOIN \r\n\t\tCrime1 CR ON A.crime_ID = CR.Crime_ID\r\n\tJOIN \r\n\t\tPunishment P ON CR.punishment_ID = P.punishment_ID\r\n\tJOIN \r\n\t\tCourt C ON P.court_ID = C.court_ID\r\n\tJOIN \r\n\t\tJudge J ON C.judge_ID = J.judge_ID\r\n WHERE A.accused_name = @accusedName;";

                using (SqlCommand command = new SqlCommand(sqlQuery, connection))
                {
                    SqlParameter paramAccusedName = new SqlParameter("@accusedName", SqlDbType.NVarChar);
                    paramAccusedName.Value = accusedName; // Assign accusedName to the parameter
                    command.Parameters.Add(paramAccusedName);
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        adapter.Fill(dataTable);
                    }
                }
            }

            return dataTable;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           
        }

       // public DataTable SearchAccusedByName(string namee)
        //{
            
       // }


            private void button1_Click(object sender, EventArgs e)
        {
            string accusedName = textBox1.Text;

            // Create a DataTable to store the query results
            DataTable resultTable = new DataTable();

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();

                // SQL query to retrieve information based on accused's name
                string query = @"
                SELECT
                    Accused1.accused_name,
                    Crime1.Crime_ID,
                    Punishment.punishment_ID,
                    Court.Court_ID,
                    Judge.judge_ID,
                    Victim1.victim_ID
                FROM
                    Accused1
                JOIN
                    Crime1 ON Accused1.crime_ID = Crime1.Crime_ID
                JOIN
                    Punishment ON Accused1.punishment_ID = Punishment.punishment_ID
                JOIN
                    Court ON Accused1.court_ID = Court.Court_ID
                JOIN
                    Judge ON Court.judge_ID = Judge.judge_ID
                JOIN
                    Victim1 ON Crime1.Crime_ID = Victim1.crime_ID
                WHERE
                    Accused1.accused_name = @AccusedName";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Add parameters to prevent SQL injection
                    command.Parameters.AddWithValue("@AccusedName", accusedName);

                    // Use a SqlDataAdapter to fill the DataTable with the query result
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    adapter.Fill(resultTable);
                }
            }

            // Display the result in a DataGridView
            dataGridView1.DataSource = resultTable;

            // Check if records were found
            if (resultTable.Rows.Count == 0)
            {
                MessageBox.Show("Records not found.");
            }
        }
        

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }
    }
}
